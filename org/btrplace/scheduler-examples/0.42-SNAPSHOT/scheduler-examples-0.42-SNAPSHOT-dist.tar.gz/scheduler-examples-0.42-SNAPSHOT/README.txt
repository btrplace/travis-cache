Btrplace examples
===============================

This distribution contains the source code of the different tutorials
related to the usage of btrplace-solver.

The documentation associated to the tutorials is available online at
"https://github.com/fhermeni/btrplace-solver/wiki"

Usage
-------------------------------

The source code of the tutorials is in "src/btrplace/examples". The following
command compiles then launches the tutorial "GettingStarted".

$ ./btrplace-tut.sh GettingStarted

Copyright
-------------------------------
Copyright (c) 2013 University of Nice-Sophia Antipolis.
See `LICENSE.txt` for details
